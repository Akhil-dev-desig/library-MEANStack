// for routes
const express = require('express');
// for mongoose third party module
const mongoose = require('mongoose');
// for connection string
const path=require ('path');
const config = require('../config/database');
// configuring router OR Creating an object of Router
const router = express.Router();
//import from quote.model.js Module
let Book = require('../models/book.model');
//const multer = require('multer');
//var fs = require('fs');


// STEP3 - CONNECT MONGODB DATABASE
//Connecting Mongodb server
mongoose.connect(config.DB,
    { useNewUrlParser: true, useUnifiedTopology: true });

let db = mongoose.connection;
//when connection open
db.once('open', function () {
    console.log('Connection Open with MongoDB Server ..!');
});
//check for db error
db.on('error', function (err) {
    console.log("Error : " + err.stack);
});

router.route('/books').get(function (req, res) {
    Book.find(function (err, books) {
        if (err) {
            res.status(500).json(err.stack);
            return;
        }
        res.status(200).json(books);
    });
});

// 	User.findById(req.params.id, 'firstName lastName age mobileNumber email password',
// GET /api/users/1
router.route('/books/:id')
    .get(function (req, res) {
        Book.findById(req.params.id, { __v: 0 },
            function (err, book) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                res.status(200).json(book);
            });
            
    });

// CREATE - POST - /api/users
router.route('/books').post(function (req, res) {
    var book = new Book();
    book.bookid = req.body.bookid;
    book.bookname = req.body.bookname;
    book.authorname=req.body.authorname;
    book.availablebooks=req.body.availablebooks;

    book.save(function (err) {
        if (err) {
            res.status(500).json(err.stack);
            return;
        }
        console.log("added");
        res.status(200).json({
            message
                : 'Book added !'
        })
    })
});

// DELETE /api/users/1
router.route('/books/:id')
    .delete(function (req, res) {
        // remove(), findByIdAndRemove(), deleteOne()
        Book.deleteOne({ _id: req.params.id },
            function (err, book) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                res.status(200).json({
                    message:
                        'Book successfully deleted'
                });
            })

        // User.remove({ _id: req.params.id },
        //     function (err, user) {
        //         if (err) {
        //             res.status(500).json(err.stack);
        //             return;
        //         }
        //         res.status(200).json({
        //             message:
        //                 'User successfully deleted'
        //         });
        //     })

        // User.findByIdAndRemove({_id: req.params.id}, 
        // 				(err, user) => {
        // if (err)
        // res.json(err);
        // else
        // res.json('Removed successfully');
        // });
    });

// UPDATE - PUT /api/users/1
router.route('/books/:id')
    .put(function (req, res) {
        Book.findById(req.params.id,
            function (err, book) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                book.bookid = req.body.bookid;
                book.bookname = req.body.bookname;
                book.authorname=req.body.authorname;
                book.availablebooks=req.body.availablebooks;
                // user.updateOne();
                book.save(function (err) {
                    if (err) {
                        res.status(500).json(err.stack);
                        return;
                    }

                    res.status(200).json({
                        message:
                            'Book updated!'
                    });
                });
            });
    });

// exporting all routes
module.exports = router;