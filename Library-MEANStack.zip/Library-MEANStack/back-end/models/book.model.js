// STEP1: IMPORT MONGOOSE MODULE
var mongoose = require('mongoose');

// STEP2: CREATE SCHEMA OBJECT
const Schema = mongoose.Schema;

// STEP3: CREATE OUR SCHEMA WITH OPTIONALLY ADDING VALIDATIONS
// SIMPLE SCHEMA
let Book = new Schema({
    bookid:{ type: String },       
    bookname: { type: String },
    authorname:{ type: String },
    availablebooks:{type: String},

    
    
});
// STEP4: EXPORT SCHEMA
module.exports = mongoose.model('Book', Book);