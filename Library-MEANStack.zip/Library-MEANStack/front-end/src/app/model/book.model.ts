export class Book {
    _id:string;
    bookid: string;
    bookname: string;
    authorname: string;
    availablebooks: string;
    
}