import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'book'
})
export class BookPipe implements PipeTransform {

 
  transform(bookList: any, searchText: any) {
    let updatedBookList: any;

    if (searchText)
      updatedBookList = bookList.filter(book => book.bookname.toLowerCase().startsWith(searchText.toLowerCase()));
    else
      updatedBookList = bookList;

    return updatedBookList;
  }

}
