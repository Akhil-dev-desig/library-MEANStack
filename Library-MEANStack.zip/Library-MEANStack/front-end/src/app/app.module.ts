import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserloginComponent } from './components/userlogin/userlogin.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './components/home/home.component';
import { RegisterComponent } from './components/register/register.component';
import { StudentloginComponent } from './components/studentlogin/studentlogin.component';
import { AddBookComponent } from './components/add-book/add-book.component';
import { ListBookComponent } from './components/list-book/list-book.component';
import { BookPipe } from './pipes/book.pipe';
import { DeleteBookComponent } from './components/delete-book/delete-book.component';
import { StudentlistBookComponent } from './components/studentlist-book/studentlist-book.component';

//import { AdminoperationsComponent } from './components/adminoperations/adminoperations.component';

@NgModule({
  declarations: [
    AppComponent,
    UserloginComponent,
    HomeComponent,
    RegisterComponent,
    StudentloginComponent,
    AddBookComponent,
    ListBookComponent,
    BookPipe,
    DeleteBookComponent,
    StudentlistBookComponent,
  
   // AdminoperationsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
