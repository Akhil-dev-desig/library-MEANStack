import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Book } from '../model/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  getBook() {
    throw new Error("Method not implemented.");
  }

  constructor(private http: HttpClient) { }

  baseUrl: string = "http://localhost:3000/api/books";

  // Get All Todos
  getBooks() {
    return this.http.get<Book[]>(this.baseUrl);
  }

  // Get Todos By Id
  getBookById(id: number) {
    return this.http.get<Book>(this.baseUrl + "/" +id);
  }

  // Add Todo
  createBook(book: Book) {
    return this.http.post(this.baseUrl, book);
  }

  // Modify Todo
  updateBook(book: Book) {
    return this.http.put(this.baseUrl + "/" + book._id, book);
  }

  // Delete Todos By Id
  deleteBook(_id: string) {
    return this.http.delete(this.baseUrl + "/" + _id);
  }
}

