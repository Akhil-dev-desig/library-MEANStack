import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BookService } from 'src/app/services/book.service';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;
  // onsubmit() function
  onSubmit() {
    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }
    console.log(this.addForm.value);
    this.bookService.createBook(this.addForm.value)
      .subscribe(data => {
        alert(this.addForm.controls.bookname.value + ' record is added successfully..!');
        this.router.navigate(['/list-book'])
      })
  }

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private bookService: BookService) { }


  ngOnInit() {
    this.addForm = this.formBuilder.group({
      bookid: ['',Validators.required],
      bookname: ['', Validators.required],
      authorname: ['', Validators.required],
      availablebooks: ['', Validators.required],
      
    });

  }

}

