import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminoperations',
  templateUrl: './adminoperations.component.html',
  styleUrls: ['./adminoperations.component.css']
})
export class AdminoperationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
