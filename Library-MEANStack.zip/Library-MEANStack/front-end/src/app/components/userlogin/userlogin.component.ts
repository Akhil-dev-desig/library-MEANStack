import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

    // Instance Variables -
    // By default public in Typescript
    loginForm: FormGroup;
    submitted: boolean = false;
    invalidLogin: boolean = false;
  
    // Constructor Dependency Injection
    constructor(private formBuilder: FormBuilder,
      private router: Router) { }
  
    // initializing default values to textboxes
    // and configuring validations
    ngOnInit() {
      this.loginForm = this.formBuilder.group({
        email: ['', Validators.required],
        password: ['', Validators.required],
      });
    }
  
    // this code will be executed on click of login btn
    onSubmit() {
      this.submitted = true;
      // If validation failed, it should return
      // to Validate again
      if (this.loginForm.invalid) {
        return;
      }
  
      let username
        = this.loginForm.controls.email.value;
      let password
        = this.loginForm.controls.password.value;
  
      if (username== "admin@gmail.com"||username=="akhil@gmail.com" && password == "123456") {
        localStorage.setItem("username", username);
        // localStorage.setItem("password", password);
        this.router.navigate(['/list-book']);
      }
      else {
        this.invalidLogin = true;
      }
    }
  }
  
  