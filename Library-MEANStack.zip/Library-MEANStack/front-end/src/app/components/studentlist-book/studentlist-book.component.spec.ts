import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentlistBookComponent } from './studentlist-book.component';

describe('StudentlistBookComponent', () => {
  let component: StudentlistBookComponent;
  let fixture: ComponentFixture<StudentlistBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudentlistBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentlistBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
