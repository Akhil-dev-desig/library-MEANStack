import { Component, OnInit } from '@angular/core';
import { Book } from 'src/app/model/book.model';
import { Router } from '@angular/router';
import { BookService } from 'src/app/services/book.service';

@Component({
  selector: 'app-studentlist-book',
  templateUrl: './studentlist-book.component.html',
  styleUrls: ['./studentlist-book.component.css']
})
export class StudentlistBookComponent implements OnInit {

  books: Book[];
  // filtering by name
  searchText: any;
  constructor(private router: Router
    , private bookService: BookService) { }

  // logOff Todo
  logOutBook(): void {
    if (localStorage.getItem("username") != null) {
      localStorage.removeItem("username");
      this.router.navigate(['/']);
    }
  }



  // loading all todos as soon as component
  // gets loaded
  ngOnInit() {
    if (localStorage.getItem("username") != null) {
      this.bookService.getBooks().subscribe(data => {
        this.books = data;
      });
    }
    else {
      this.router.navigate(['/studentlist-book']);
    }
  }

  // Delete Todo
  deleteBook(book: Book): void {
    let result = confirm("Do You want to delete book?");
    if (result) {
      this.bookService.deleteBook(book._id)
        .subscribe(data => {
          this.books = this.books.filter
            (u => u !== book);
        })
      alert(`${book.bookname} record is deleted ..!`);

      // this will return me empty list
      // .subscribe(data => {
      // this.todo = <todo[]> data;
      //})
    }
  }
  // Modify todo
 
  // Add New Todo
  addBook(): void {
    window.alert("Your selected book got added into the cart");   
    this.router.navigate(['/home']);
  }
}