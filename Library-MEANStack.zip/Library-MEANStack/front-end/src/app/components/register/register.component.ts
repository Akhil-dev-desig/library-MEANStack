import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: any;
  submitted: boolean;

  constructor(private formBuilder: FormBuilder,
private router: Router) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      studentid: ['',Validators.required],
      studentname: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  // this code will be executed on click of login btn
  onSubmit() {
    this.submitted = true;
    // If validation failed, it should return
    // to Validate again
    if (this.registerForm.invalid) {
      return;
    }

    let studentid
      = this.registerForm.controls.studentid.value;
      let studentname
      = this.registerForm.controls.studentname.value;

    let username
      = this.registerForm.controls.email.value;
    let password
      = this.registerForm.controls.password.value;

    // if (username
    //   == "admin@gmail.com" && password == "123456") {
    //   localStorage.setItem("username", username);
    //   // localStorage.setItem("password", password);
    //   this.router.navigate(['home']);
    // }
    // else {
    //   this.invalidLogin = true;
    // }
  }
}

