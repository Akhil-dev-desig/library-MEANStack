import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserloginComponent } from './components/userlogin/userlogin.component';
import { HomeComponent } from './components/home/home.component';
import { RegisterComponent } from './components/register/register.component';
import { StudentloginComponent } from './components/studentlogin/studentlogin.component';
import { AddBookComponent } from './components/add-book/add-book.component';
import { ListBookComponent } from './components/list-book/list-book.component';
import { StudentlistBookComponent } from './components/studentlist-book/studentlist-book.component';



const routes: Routes = [
  { path: 'userlogin', component: UserloginComponent },
  { path: 'register', component: RegisterComponent},
  { path: 'studentlogin', component: StudentloginComponent},
  { path: 'add-book', component: AddBookComponent},
  { path: 'list-book', component: ListBookComponent},
  { path: 'studentlist-book', component: StudentlistBookComponent},




  {path: '', component: HomeComponent},
  {path: '**', component: HomeComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
